import { NCPInputForm } from "./components/ncp-input-form"

export default function NCPInputPage() {
  return <NCPInputForm />
}
